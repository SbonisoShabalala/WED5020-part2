/* JavaScript is reserved for Part 3; Part 2 works without it. */
