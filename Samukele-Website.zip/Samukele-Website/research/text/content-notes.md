# Content research and provenance

- The two proposals and chosen proposal are preserved under `research/documents/`.
- The four transport images were supplied in the Part 1 ZIP; renamed copies are used in `images/`. Photographer, licence and consent are unknown. Obtain permission before publishing.
- The original competitor research screenshot is in `research/images/`. It is reference material only, not reproduced as page content.
- Copy on the revised site is newly drafted from the student's proposal. Business facts such as establishment date, contact details, staff names, actual operating regions and credentials need client approval.
- Durban appeared in the original HTML as a location. Johannesburg is marked only as an example route destination, not an office.
- The student should gather interview notes, approved business profile, route examples, certifications, image permissions and exact addresses for the final research pack.
