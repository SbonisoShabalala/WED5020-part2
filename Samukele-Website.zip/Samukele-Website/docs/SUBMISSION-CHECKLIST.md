# Part 2 submission checklist

1. Open all eight pages in a browser and review content and layout.
2. The supplied desktop, tablet, and mobile homepage screenshots are saved in `screenshots/` and embedded in the README. Check those layouts yourself, then test the other pages at desktop, tablet and mobile widths.
3. Record browser/device details and actual outcomes in the README; verify a second browser if possible.
4. Confirm the student's name, original research references, image rights, business claims, and the institution's citation format.
5. Commit the actual work in the lecturer's assigned private GitHub repository using descriptive messages. Push it and confirm the remote contains the files and README screenshots. A ZIP cannot establish earlier commit history.
6. Submit the correct private repository URL and any separately requested proposal PDF or research ZIP through the LMS.

The lecturer determines the mark. No score can be guaranteed by this package.
