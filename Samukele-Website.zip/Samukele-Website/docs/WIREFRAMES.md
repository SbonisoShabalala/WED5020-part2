# Low fidelity wireframes

These are planning diagrams. The rendered pages implement the same hierarchy.

## Home, desktop
| Header and eight-page navigation | Quote action |
|---|---|
| Large value proposition, introduction and calls to action | Hero transport image |
| Three service cards across | Three service cards across |
| Full-width enquiry banner | Full-width enquiry banner |
| Footer with navigation and project note | Footer |

## Interior page, desktop
| Header | Header |
|---|---|
| Page heading and introduction | Page heading and introduction |
| Main copy or form | Supporting image or information |
| Footer | Footer |

## Mobile
| Vertical order |
|---|
| Brand and quote action |
| Scrollable navigation |
| Page heading and introduction |
| Hero image or section image |
| Stacked cards / form fields |
| Footer |

At narrow widths navigation remains visible and scrollable, rather than depending on JavaScript. The enquiry and contact forms use distinct page purposes.
