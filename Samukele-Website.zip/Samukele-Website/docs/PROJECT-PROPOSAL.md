# Website Project Proposal
**Student:** ST10499221  
**Chosen organisation:** Samukele Trading and Projects (Pty) Ltd  
**Project:** Transport and abnormal load escort information website  
**Revision:** 25 September 2026, following Part 1 feedback

## Organisation overview
The Part 1 submission describes Samukele as a South African small business focused on transport support and abnormal load escort services. Its date of establishment, staff biographies, registration details and operational credentials were not supplied; these require verification with the organisation. Proposed mission: help coordinate abnormal load movements safely and efficiently. Proposed vision: become a trusted contact for route planning and escort support. Target users are transport operators, logistics managers, construction and mining firms.

## Existing website and goals
The Part 1 proposal states that the organisation had no website. This has not been independently verified. The proposed site aims to establish an accessible online presence, explain services and let a prospective client prepare a route enquiry. Measurable targets for a three-month launch review: 50 relevant visits per month; 10 completed enquiries per month; all eight pages available on desktop and mobile; no internal broken links. These are proposed targets, not recorded results.

## Scope
Eight pages: Home, About, Services, Compliance & Safety, Service Areas, Gallery, Request a Quote and Contact. The site uses semantic HTML, a shared external CSS file, responsive layouts, source images from the original submission and an email-app form for demonstration. The site does not process or store form data. Server-side submission, verified office details, credentials, map markers, testimonials and a company profile PDF require client information and belong to a future phase.

## Visual approach
Safety yellow, charcoal, white and a warm light background create a strong transport identity. Clear headings, legible text, a consistent navigation bar and prominent quote links help users find the next action. Desktop uses Grid and Flexbox; tablet wraps navigation; mobile displays one-column content.

## Timeline and milestones
| Milestone | Estimated time | Output |
|---|---:|---|
| Confirm organisation content and image rights | 2 days | Approved copy and assets |
| Plan sitemap and wireframes | 2 days | Page map and layouts |
| Repair Part 1 HTML and documentation | 3 days | Working pages and README |
| Build Part 2 desktop CSS | 3 days | Shared stylesheet |
| Tablet and mobile refinement | 2 days | Breakpoints and responsive images |
| Cross-device review and corrections | 2 days | Screenshot evidence and issue log |
| Repository submission | 1 day | Commits, push and LMS link |

## Illustrative budget (ZAR)
| Item | Estimate | Basis |
|---|---:|---|
| Research, content review and wireframes | R2,400 | 12 hours at R200/hour |
| HTML/CSS implementation | R6,400 | 32 hours at R200/hour |
| Testing and documentation | R1,600 | 8 hours at R200/hour |
| Domain and hosting, first year | R1,500 | Planning allowance, supplier quote required |
| Maintenance, first year | R2,400 | 2 hours/month at R100/hour |
| **Estimated first year** | **R14,300** | Excludes VAT and paid integrations |

This is a planning estimate, not a vendor quote. Confirm current supplier pricing and client scope before procurement.

## Source and approval notes
Original material: student's Part 1 proposal, HTML pages and four submitted images (see `research/`). The assignment screenshots and lecturer feedback directed this revision. No external factual claim about certification, road permissions, company history or locations is asserted as verified. Refer to `README.md` for the full source register and outstanding confirmations.
