# Browser evidence

Student-supplied Chrome responsive-mode homepage captures: `desktop.png`, `tablet.png`, and `mobile.png`. They are embedded in the main README.
